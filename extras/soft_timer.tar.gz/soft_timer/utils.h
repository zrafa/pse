/* utils.h - definicion de funciones utiles al TP5 */

#ifndef _UTILS_H
#define _UTILS_H

void toggle13(void);
void leds_init();

#endif	/* _UTILS_H */
