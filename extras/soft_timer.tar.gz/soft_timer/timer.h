
#ifndef _CLOCK_H
#define _CLOCK_H

void timer0_init( void );

#endif
