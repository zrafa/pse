soft_timer

Un driver que implementa tareas periódicas
controladas por un único timer en hardware.

Cada tarea tiene asociada un timer de software.

Programa de ejemplo que implementa timers por software de manera sencilla,
y ejecuta tareas periódicas en base a estos timers.

Compilar con :

```
make clean
make 
make flash  # transfiere el firmware al AVR
```


