
#ifndef BUFFER_H
#define BUFFER_H

void buffer_init(void);
void buffer_put(int n);
int buffer_get();

#endif	/* BUFFER_H */
