
void main(void) {
	for(;;);
}

