
#define NLINES 6
#define LINE_LEN 32

