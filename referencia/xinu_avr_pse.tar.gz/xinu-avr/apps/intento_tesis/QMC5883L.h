
#ifndef _QMC5883L_H
#define _QMC5883L_H

int mostrar_angulo(void);
void magnetometro_init(void);

#endif 
