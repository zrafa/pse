#include <avr/interrupt.h>
#include "timer.h"

int main(void)
{
	
	DDRB = 0x02;

	timer1_init();
	volatile unsigned long i;

	while(1){
		for(i = 0; i < 450000;i++);
		/*mover_izq();
		for(i = 0; i < 450000;i++);
		apagar();
		for(i = 0; i < 450000;i++);
		mover_der();*/
		mover();
		
	}
}




