
#ifndef _CLOCK_H
#define _CLOCK_H

void timer1_init( void );
void mover_der();
void mover_izq();
void apagar();
void mover();
#endif
